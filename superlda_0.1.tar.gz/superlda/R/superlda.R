#' superlda
#'
#' Fits supervised, generative models.
#'
#' @docType package
#' @author Travis G. Coan <t.coan@exeter.ac.uk>
#' @import Rcpp RcppArmadillo
#' @useDynLib superlda
#' @name superlda
NULL
